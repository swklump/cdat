from django.apps import AppConfig

class CDATConfig(AppConfig):
    name = 'CDAT'
