from setuptools import setup

setup(
    name='HDR_CAT',
    version='0.1dev',
    packages=['CAT',],
    install_requires=['matplotlib','django'],
    url='http://HDRCAT.com',
    author='RoadSafetyEIT',
    author_email='samuel.klump@hdrinc.com',
    license='Creative Commons Attribution-Noncommercial-Share Alike license',
    long_description=open('README.txt').read(),
)