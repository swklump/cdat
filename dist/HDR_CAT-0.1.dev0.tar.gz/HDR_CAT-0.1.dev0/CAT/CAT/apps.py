from django.apps import AppConfig

class CATConfig(AppConfig):
    name = 'CAT'
